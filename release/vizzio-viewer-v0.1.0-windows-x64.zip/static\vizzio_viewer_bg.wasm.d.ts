/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_vizzioviewer_free: (a: number, b: number) => void;
export const vizzioviewer_clear_selection: (a: number) => void;
export const vizzioviewer_geometry_count: (a: number) => number;
export const vizzioviewer_get_selected_index: (a: number) => number;
export const vizzioviewer_get_selected_info: (a: number) => [number, number];
export const vizzioviewer_init_canvas: (a: number, b: number, c: number) => [number, number];
export const vizzioviewer_load_ifc: (a: number, b: number, c: number) => [number, number];
export const vizzioviewer_new: () => number;
export const vizzioviewer_orbit_camera: (a: number, b: number, c: number) => void;
export const vizzioviewer_pick_object: (a: number, b: number, c: number) => number;
export const vizzioviewer_render: (a: number) => [number, number];
export const vizzioviewer_set_xr_projection_matrix: (a: number, b: number, c: number) => void;
export const vizzioviewer_set_xr_view_matrix: (a: number, b: number, c: number) => void;
export const vizzioviewer_zoom_camera: (a: number, b: number) => void;
export const main: () => void;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
