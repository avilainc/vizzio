/* tslint:disable */
/* eslint-disable */

export class VizzioViewer {
  free(): void;
  [Symbol.dispose](): void;
  /**
   * Inicializa renderer no canvas
   */
  init_canvas(canvas_id: string): void;
  /**
   * Testa seleção de objeto com raycasting
   *
   * # Arguments
   * * `screen_x` - Coordenada X do mouse normalizada (-1 a 1)
   * * `screen_y` - Coordenada Y do mouse normalizada (-1 a 1)
   *
   * # Returns
   * Índice da geometria selecionada, ou -1 se nada foi atingido
   */
  pick_object(screen_x: number, screen_y: number): number;
  /**
   * Zoom câmera
   */
  zoom_camera(delta: number): void;
  /**
   * Orbita câmera
   */
  orbit_camera(delta_x: number, delta_y: number): void;
  /**
   * Obtém número de geometrias carregadas
   */
  geometry_count(): number;
  /**
   * Limpa seleção
   */
  clear_selection(): void;
  /**
   * Obtém informações do objeto selecionado
   * Retorna string JSON com: {"id": 123, "type": "IFCWALL", "vertices": 8, "triangles": 12}
   */
  get_selected_info(): string;
  /**
   * Obtém índice do objeto atualmente selecionado
   */
  get_selected_index(): number;
  /**
   * Define matriz de view para XR
   */
  set_xr_view_matrix(matrix: Float32Array): void;
  /**
   * Define matriz de projeção para XR
   */
  set_xr_projection_matrix(matrix: Float32Array): void;
  constructor();
  /**
   * Renderiza frame
   */
  render(): void;
  /**
   * Carrega arquivo IFC
   */
  load_ifc(ifc_content: string): void;
}

export function main(): void;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly __wbg_vizzioviewer_free: (a: number, b: number) => void;
  readonly vizzioviewer_clear_selection: (a: number) => void;
  readonly vizzioviewer_geometry_count: (a: number) => number;
  readonly vizzioviewer_get_selected_index: (a: number) => number;
  readonly vizzioviewer_get_selected_info: (a: number) => [number, number];
  readonly vizzioviewer_init_canvas: (a: number, b: number, c: number) => [number, number];
  readonly vizzioviewer_load_ifc: (a: number, b: number, c: number) => [number, number];
  readonly vizzioviewer_new: () => number;
  readonly vizzioviewer_orbit_camera: (a: number, b: number, c: number) => void;
  readonly vizzioviewer_pick_object: (a: number, b: number, c: number) => number;
  readonly vizzioviewer_render: (a: number) => [number, number];
  readonly vizzioviewer_set_xr_projection_matrix: (a: number, b: number, c: number) => void;
  readonly vizzioviewer_set_xr_view_matrix: (a: number, b: number, c: number) => void;
  readonly vizzioviewer_zoom_camera: (a: number, b: number) => void;
  readonly main: () => void;
  readonly __wbindgen_exn_store: (a: number) => void;
  readonly __externref_table_alloc: () => number;
  readonly __wbindgen_externrefs: WebAssembly.Table;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __externref_table_dealloc: (a: number) => void;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
